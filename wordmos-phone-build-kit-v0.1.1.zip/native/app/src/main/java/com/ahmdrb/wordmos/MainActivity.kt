package com.ahmdrb.wordmos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ahmdrb.wordmos.data.*
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { WordmosApp() } }
}

@Composable fun WordmosApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { WordmosDatabase.get(context).dao() }
    val documents by dao.documents().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<DocumentEntity?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(topBar = { TopAppBar(title = { Text(selected?.title ?: "Wordmos") }, actions = { if (selected != null) TextButton(onClick = { selected = null }) { Text("Library") } }) }) { pad ->
            if (selected == null) LibraryScreen(documents, Modifier.padding(pad), onOpen = { selected = it }, onAdd = { showAdd = true })
            else TreeScreen(selected!!, dao, Modifier.padding(pad))
        }
        if (showAdd) AddDocumentDialog(onDismiss = { showAdd = false }) { title -> scope.launch { val d = DocumentEntity(UUID.randomUUID().toString(), title); dao.insertDocument(d); showAdd = false } }
    }
}

@Composable fun LibraryScreen(docs: List<DocumentEntity>, modifier: Modifier, onOpen: (DocumentEntity)->Unit, onAdd:()->Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) { Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("+ New Portrait") }; Spacer(Modifier.height(16.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(docs) { d -> Card(onClick = { onOpen(d) }, modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(d.title, style = MaterialTheme.typography.titleMedium); Text("Local • offline", style = MaterialTheme.typography.bodySmall) } } } } }
}

@Composable fun TreeScreen(doc: DocumentEntity, dao: WordmosDao, modifier: Modifier) {
    val nodes by dao.nodes(doc.id).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val roots = nodes.filter { it.parentId == null }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items(roots, key = { it.id }) { root -> NodeView(root, nodes, 0) { node, newParent -> kotlinx.coroutines.GlobalScope.launch { dao.updateNode(node.copy(parentId = newParent)) } } }
    }
}

@Composable fun NodeView(node: NodeEntity, all: List<NodeEntity>, depth: Int, onMove:(NodeEntity,String?)->Unit) {
    Column { Card(modifier = Modifier.fillMaxWidth().padding(start = (depth * 18).dp)) { Column(Modifier.padding(12.dp)) { Text(node.title, style = MaterialTheme.typography.titleMedium); if (node.description.isNotBlank()) Text(node.description, style = MaterialTheme.typography.bodyMedium) } }; all.filter { it.parentId == node.id }.sortedBy { it.position }.forEach { NodeView(it, all, depth + 1, onMove) } }
}

@Composable fun AddDocumentDialog(onDismiss:()->Unit, onCreate:(String)->Unit) { var title by remember { mutableStateOf("") }; AlertDialog(onDismissRequest = onDismiss, title = { Text("New Portrait") }, text = { OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true) }, confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { onCreate(title.trim()) }) { Text("Create") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }) }
